﻿namespace $rootnamespace$ {
	using System.Windows;

	internal partial class $safeitemrootname$ : Window {
	        public $safeitemrootname$() {
	        	InitializeComponent();
		}
	}
}
