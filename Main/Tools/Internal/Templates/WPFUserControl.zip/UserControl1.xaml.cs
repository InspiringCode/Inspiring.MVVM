﻿namespace $rootnamespace$ {
	using System.Windows.Controls;

	internal partial class $safeitemrootname$ : UserControl	{
		public $safeitemrootname$() {
			InitializeComponent();
		}
	}
}
