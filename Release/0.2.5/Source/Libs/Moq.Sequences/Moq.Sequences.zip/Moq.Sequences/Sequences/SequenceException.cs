using System;

namespace Moq.Sequences
{
    public class SequenceException : Exception
    {
        public SequenceException(string message) : base(message)
        {            
        }
    }
}