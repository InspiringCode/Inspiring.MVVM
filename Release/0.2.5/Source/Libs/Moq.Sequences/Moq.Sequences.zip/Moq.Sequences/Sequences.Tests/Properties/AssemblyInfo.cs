﻿using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("Moq.Sequences.Test")]
[assembly: AssemblyDescription("Supports checking that Moq setups are executed in sequence.")]
[assembly: AssemblyProduct("Moq.Sequences.Test")]
[assembly: AssemblyCopyright("Declan Whelan © 2010")]

[assembly: ComVisible(false)]
[assembly: Guid("cc982e5b-5e44-44f2-9b18-b8afbd2897c8")]

[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]
