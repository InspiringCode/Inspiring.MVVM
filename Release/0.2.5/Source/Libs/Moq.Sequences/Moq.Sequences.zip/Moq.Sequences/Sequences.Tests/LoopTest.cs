using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace Moq.Sequences.Test {
   [TestClass]
   public class LoopTest {
      [TestMethod]
      public void A_new_loop_should_be_added_directly_if_it_contains_no_child_loops() {
         using (var loop = new Loop(Times.Once())) {
            using (var child = loop.CreateLoop(Times.Once())) {
               Assert.IsTrue(loop.Steps.Contains(child));
            }
         }
      }

      [TestMethod]
      public void A_new_loop_should_be_added_to_most_recently_created_child_loop() {
         using (var loop = new Loop(Times.Once())) {
            using (var child1 = loop.CreateLoop(Times.Once())) {
               using (loop.CreateLoop(Times.Once())) {
               }

               using (var child2 = loop.CreateLoop(Times.Once())) {
                  Assert.IsTrue(child1.Steps.Contains(child2));

                  using (var child3 = loop.CreateLoop(Times.Once())) {
                     Assert.IsTrue(child2.Steps.Contains(child3));
                  }
               }
            }
         }
      }

      [TestMethod]
      public void A_new_step_should_be_added_directly_if_it_contains_no_child_loops() {
         using (var loop = new Loop(Times.Once())) {
            var step = loop.CreateStep("", Times.Once());

            Assert.IsTrue(loop.Steps.Contains(step));
         }
      }

      [TestMethod]
      public void A_new_step_should_be_added_to_most_recently_created_child_loop() {
         using (var loop = new Loop(Times.Once())) {
            using (loop.CreateLoop(Times.Once())) {
               using (loop.CreateLoop(Times.Once())) {
               }

               using (var child2 = loop.CreateLoop(Times.Once())) {
                  var step2 = loop.CreateStep("", Times.Once());
                  Assert.IsTrue(child2.Steps.Contains(step2));

                  using (var child3 = loop.CreateLoop(Times.Once())) {
                     var step3 = loop.CreateStep("", Times.Once());
                     Assert.IsTrue(child3.Steps.Contains(step3));
                  }
               }
            }
         }
      }

      [TestMethod]
      [ExpectedException(typeof(SequenceException))]
      public void RecordCall_should_throw_when_step_count_exceeded() {
         using (var loop = new Loop(Times.Once())) {
            var step = loop.CreateStep("", Times.Exactly(2));

            loop.RecordCall(step);
            loop.RecordCall(step);

            loop.RecordCall(step);
         }
      }

      [TestMethod]
      [ExpectedException(typeof(SequenceException))]
      public void RecordCall_should_throw_when_loop_count_exceeded() {
         using (var loop = new Loop(Times.Exactly(2))) {
            var step1 = loop.CreateStep("", Times.Once());
            var step2 = loop.CreateStep("", Times.Once());

            loop.RecordCall(step1); loop.RecordCall(step2);
            loop.RecordCall(step1); loop.RecordCall(step2);

            loop.RecordCall(step1);
         }
      }

      [TestMethod]
      [ExpectedException(typeof(SequenceException))]
      public void RecordCall_should_throw_if_steps_called_out_of_sequence() {
         using (var loop = new Loop(Times.Once())) {
            loop.CreateStep("", Times.Once());
            var step = loop.CreateStep("", Times.Once());

            loop.RecordCall(step);
         }
      }

      [TestMethod]
      [ExpectedException(typeof(SequenceException))]
      public void RecordCall_should_throw_when_child_loop_count_exceeded() {
         using (var loop = new Loop(Times.Once())) {
            Step step1;
            Step step2;

            using (loop.CreateLoop(Times.Exactly(2))) {
               step1 = loop.CreateStep("", Times.Once());
               step2 = loop.CreateStep("", Times.Once());
            }

            loop.RecordCall(step1); loop.RecordCall(step2);
            loop.RecordCall(step1); loop.RecordCall(step2);

            loop.RecordCall(step1);
         }
      }

      [TestMethod]
      public void Record_call_should_ensure_all_previous_steps_completed() {
         using (var loop = new Loop(Times.Once())) {
            var stepBefore = loop.CreateStep("", Times.AtMostOnce());

            Loop nested;
            Step stepNested;

            using (nested = loop.CreateLoop(Times.Once())) {
               stepNested = loop.CreateStep("", Times.Once());
            }

            var stepAfter = loop.CreateStep("", Times.Once());

            loop.RecordCall(stepNested);
            Assert.IsTrue(stepBefore.Complete);
            Assert.IsFalse(loop.Complete);
            Assert.IsFalse(stepNested.Complete);
            Assert.IsFalse(stepAfter.Complete);

            loop.RecordCall(stepAfter);

            Assert.IsTrue(stepBefore.Complete);
            Assert.IsTrue(nested.Complete);
            Assert.IsTrue(stepNested.Complete);
            Assert.IsFalse(stepAfter.Complete);
         }
      }

      [TestMethod]
      [ExpectedException(typeof(SequenceException))]
      public void EnsureComplete_should_throw_if_minimum_count_not_met() {
         using (var loop = new Loop(Times.Once())) {
            loop.EnsureComplete("");
         }
      }

      [TestMethod]
      [ExpectedException(typeof(SequenceException))]
      public void EnsureComplete_should_throw_if_maximum_count_not_met() {
         using (var loop = new Loop(Times.AtLeastOnce())) {
            loop.EnsureComplete("");
         }
      }

      [TestMethod]
      public void EnsureComplete_should_not_throw_if_minimum_and_maximum_count_met() {
         using (var loop = new Loop(Times.Never())) {
            loop.EnsureComplete("");
            Assert.IsTrue(loop.Complete);
         }
      }

      [TestMethod]
      [ExpectedException(typeof(SequenceUsageException))]
      public void Dispose_should_throw_if_child_loops_not_disposed() {
         using (var loop = new Loop(Times.Once())) {
            loop.CreateLoop(Times.Exactly(2));
         }
      }

      [TestMethod]
      public void Dispose_should_do_nothing_if_called_multiple_times() {
         using (var loop = new Loop(Times.Once())) {
            loop.Dispose();
            loop.Dispose();
         }
      }
   }
}