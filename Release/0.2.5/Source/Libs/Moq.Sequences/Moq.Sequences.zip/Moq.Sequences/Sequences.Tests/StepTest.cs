using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace Moq.Sequences.Test {
   [TestClass]
   public class StepTest {
      [TestMethod]
      [ExpectedException(typeof(SequenceException))]
      public void Should_throw_immediately_once_call_count_exceeds_maximum() {
         var step = new Step(Times.AtMostOnce());

         step.CountCall();
         step.CountCall();
      }

      [TestMethod]
      [ExpectedException(typeof(SequenceException))]
      public void Should_not_be_complete_if_call_count_less_than_minimum() {
         var step = new Step(Times.AtLeastOnce());

         step.EnsureComplete("");
      }

      [TestMethod]
      [ExpectedException(typeof(SequenceException))]
      public void Should_throw_if_CountCall_invoked_after_step_is_complete() {
         var step = new Step(Times.AtMostOnce());

         step.EnsureComplete("");

         step.CountCall();
      }

      [TestMethod]
      public void Should_only_be_started_after_first_call() {
         var step = new Step(Times.AtMostOnce());

         Assert.IsFalse(step.Started);

         step.CountCall();

         Assert.IsTrue(step.Started);
      }

      [TestMethod]
      [ExpectedException(typeof(SequenceException))]
      public void EnsureComplete_should_throw_if_minimum_count_not_met() {
         var step = new Step(Times.Once());

         step.EnsureComplete("");
      }

      [TestMethod]
      [ExpectedException(typeof(SequenceException))]
      public void EnsureComplete_should_throw_if_maximum_count_not_met() {
         var step = new Step(Times.AtLeastOnce());

         step.EnsureComplete("");
      }

      [TestMethod]
      public void EnsureComplete_should_not_throw_if_minimum_and_maximum_count_met() {
         var step = new Step(Times.Once());
         step.CountCall();

         step.EnsureComplete("");
         Assert.IsTrue(step.Complete);
      }

      [TestMethod]
      [ExpectedException(typeof(SequenceUsageException))]
      public void Dispose_should_throw_if_child_loops_not_disposed() {
         using (var loop = new Loop(Times.Once())) {
            loop.CreateLoop(Times.Exactly(2));
         }
      }

      [TestMethod]
      public void Reset_should_clear_call_count_and_Complete_status() {
         var step = new Step(Times.Once());
         step.CountCall();

         step.EnsureComplete("");

         step.Reset();
         Assert.IsFalse(step.Complete);
         step.CountCall();
      }

      [TestMethod]
      public void Reset_should_make_Started_property_true() {
         var step = new Step(Times.AtMostOnce());
         step.CountCall();
         Assert.IsTrue(step.Started);

         step.Reset();

         Assert.IsFalse(step.Started);
      }
   }
}