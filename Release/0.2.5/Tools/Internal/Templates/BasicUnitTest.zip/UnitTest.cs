﻿namespace $rootnamespace$ {
	using System;
	$if$ ($targetframeworkversion$ == 3.5)using System.Linq;$endif$$if$ ($targetframeworkversion$ == 4.0)using System.Linq;
	$endif$using Microsoft.VisualStudio.TestTools.UnitTesting;

	[TestClass]
	public class $safeitemname$ {
		[TestMethod]
		public void TestMethod1() {
			
		}
	}
}